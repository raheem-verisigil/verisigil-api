# VeriSigil AI — API Server

The live API backend for VeriSigil AI.

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET  | / | API info |
| GET  | /health | Health check |
| POST | /v1/passport/issue | Issue a passport |
| GET  | /v1/passport/{id} | Get a passport |
| POST | /v1/passport/verify | Verify a passport |
| POST | /v1/passport/revoke | Revoke a passport |
| POST | /v1/security/scan | Scan code |
| POST | /v1/compliance/check | Check compliance |

## Environment Variables

```
SUPABASE_URL=your-supabase-url
SUPABASE_KEY=your-supabase-anon-key
SIGN_SECRET=your-random-secret
```

## Deploy

Click the button in Railway and set the 3 environment variables.
